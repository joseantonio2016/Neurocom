
<h3> Find eBay Items</h3>

<div class="form">
    
  <div class="form-group">
    <label for="search_ebay">Enter eBay ID </label>
    <input type="text" class="form-control" id="ebayid" name="ebayid" placeholder="Enter eBay ID Here">
    
  </div>
 
  
  <button type="submit" id="btnEbayId" class="btn btn-primary">Submit</button>
</div>

<div id="result">
    
</div>

 