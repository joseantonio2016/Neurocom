<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://ekumar.com.np
 * @since      1.0.0
 *
 * @package    Import_Ebay_Product_To_Woocommerce
 * @subpackage Import_Ebay_Product_To_Woocommerce/admin/partials
 */
 




?>
