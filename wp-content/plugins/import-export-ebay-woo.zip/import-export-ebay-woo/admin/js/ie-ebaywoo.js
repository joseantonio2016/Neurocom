$(document).ready(function(){
	$("#saveKeys").on('click', function(e){
        //e.preventDefaults();
        alert("holaa");
        // var eappid = $("#eAppId").val();
        // var edevid = $("#eDevId").val();
        // var ecertid = $("#eCertId").val();
        // var etoken = $("#eToken").val();
        // var siteid = $('#site_id_s').val();
        // var email = $('#eMail').val();
        
        // var ambito = $("input[name='typeID']:checked").val();//register_eybadev_ajax
        // var datos = {
        //         appid : eappid,
        //         devid : edevid,
        //         certid : ecertid,
        //         email : email,
        //         token : etoken,
        //         siteid : siteid,
        //         ambito : ambito
        //     }
            
        //$.post(ebay_ajax+"?action=register_ebaydev", datos, function(result){
            //$("#result_setting").html(result);
        //});
      });
})